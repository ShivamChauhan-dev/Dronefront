import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import './DPRreport.css'; // Link the external CSS file

const DPRreport = () => {
  const [personnelData, setPersonnelData] = useState([]);
  const [equipmentData, setEquipmentData] = useState([]);
  const [flightData, setflighttData] = useState([]);

  const [formData, setFormData] = useState({
    project_name:'',
    name:'',
    designation:'',
    phone:'',
    hour_at_start:'',
    start_time1:'',
    weather_forecast1:'',
    wind_speed1:'',
    visibility1:'',
    start_time2:'',
    eather_forecast2:'',
    wind_speed2:'',
    visibility2:'',
    equipment:'',
    serial_no:'',
    health_condition:'',
    remarks:'',
    prepared:'',
    checked:'',
    approved:'',
    signature1:'',
    signature2:'',
    signature3:'',
    flight_no:'',
    equipment2:'',
    flight_start_time:'',
    flight_end_time:'',
    remark:'',
    total_work:'',
    total_done:'',
    todays_work:'',
    total_remaining:''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/Admin/dpr', formData);
      console.log('DPR inserted successfully.');
      toast.success('DPR inserted successfully.');
      // Reset the form after successful submission
      setFormData({
        project_name:'',
        name:'',
        designation:'',
        phone:'',
        hour_at_start:'',
        start_time1:'',
        weather_forecast1:'',
        wind_speed1:'',
        visibility1:'',
        start_time2:'',
        eather_forecast2:'',
        wind_speed2:'',
        visibility2:'',
        equipment:'',
        serial_no:'',
        health_condition:'',
        remarks:'',
        prepared:'',
        checked:'',
        approved:'',
        signature1:'',
        signature2:'',
        signature3:'',
        flight_no:'',
        equipment2:'',
        flight_start_time:'',
        flight_end_time:'',
        remark:'',
        total_work:'',
        total_done:'',
        todays_work:'',
        total_remaining:''
      });
    } catch (error) {
      console.error('Error inserting data:', error);
    }
  };

  useEffect(() => {
    // Initialize with a default entry when the component mounts
    setPersonnelData([{ name: '', designation: '', phone: '', hoursAtSite: '' }]);
    setEquipmentData([{ equipment: '', serialNumber: '', healthCondition: '', remarks: '' }]);
    setflighttData([{ FlightNo: '', Equipment: '', FlightStartTime: '', FlightEndTime: '', Remark: '' }]);
  }, []);

  const addPersonnel = () => {
    setPersonnelData([...personnelData, { name: '', designation: '', phone: '', hoursAtSite: '' }]);
  };

  const addEquipment = () => {
    setEquipmentData([...equipmentData, { equipment: '', serialNumber: '', healthCondition: '', remarks: '' }]);
  };

  const addFlight = () => {
    setflighttData([...flightData, { FlightNo: '', Equipment: '', FlightStartTime: '', FlightEndTime: '', Remark: '' }]);
  };

  const handlePersonnelChange = (index, field, value) => {
    const updatedPersonnelData = [...personnelData];
    updatedPersonnelData[index][field] = value;
    setPersonnelData(updatedPersonnelData);
  };

  const handleEquipmentChange = (index, field, value) => {
    const updatedEquipmentData = [...equipmentData];
    updatedEquipmentData[index][field] = value;
    setEquipmentData(updatedEquipmentData);
  };

  const handleFlightChange = (index, field, value) => {
    const updatedFlightData = [...flightData];
    updatedFlightData[index][field] = value;
    setflighttData(updatedFlightData);
  };

  return (
    <div className="container">
      <h2 className='headings'>Daily Progress Report</h2>
      {/* Personnel Section */}
      <div className="personnel-section">
        {/* <h3>Personnel Details</h3> */}
        {personnelData.map((personnel, index) => (
          <div key={index} className="personnel-container">
            {index === 0 && (
              <div className="personnel-labels">
                <label>Name:</label>
                <label>Designation:</label>
                <label>Phone:</label>
                <label>Hours at Site:</label>
              </div>
            )}
            <div className="personnel-inputs">
              <input
                placeholder="Name"
                value={personnel.name}
                onChange={(e) => handlePersonnelChange(index, 'name', e.target.value)}
              />
              <input
                placeholder="Designation"
                value={personnel.designation}
                onChange={(e) => handlePersonnelChange(index, 'designation', e.target.value)}
              />
              <input
                placeholder="Phone"
                value={personnel.phone}
                onChange={(e) => handlePersonnelChange(index, 'phone', e.target.value)}
              />
              <input
                placeholder="Hours at Site"
                value={personnel.hoursAtSite}
                onChange={(e) => handlePersonnelChange(index, 'hoursAtSite', e.target.value)}
              />
            </div>
          </div>
        ))}
        <button onClick={addPersonnel}>Add</button>
      </div>

      {/* Second Table */}
      <div className='second-table'>
        <table>
          <thead>
            <tr>
              <th>Details</th>
              <th>Today</th>
              <th>Next Day</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Start Time</td>
              <td><textarea></textarea></td>
              <td><textarea></textarea></td>
            </tr>
            <tr>
              <td>Weather Forecast</td>
              <td><textarea></textarea></td>
              <td><textarea></textarea></td>
            </tr>
            <tr>
              <td>Wind Speed (in mps)</td>
              <td><textarea></textarea></td>
              <td><textarea></textarea></td>
            </tr>
            <tr>
              <td>Visibility</td>
              <td><textarea></textarea></td>
              <td><textarea></textarea></td>
            </tr>
          </tbody>         </table>
      </div>

      {/* Equipment Section */}
      <div className="equipment-section">
        {/* <h3>Equipment Details</h3> */}
        {equipmentData.map((equipment, index) => (
          <div key={index} className="equipment-container">
            {index === 0 && (
              <div className="equipment-labels">
                <label>Equipment:</label>
                <label>Serial No:</label>
                <label>Health Condition:</label>
                <label>Remarks:</label>
              </div>
            )}
            <div className="equipment-inputs">
              <input
                placeholder="Equipment"
                value={equipment.equipment}
                onChange={(e) => handleEquipmentChange(index, 'equipment', e.target.value)}
              />
              <input
                placeholder="Serial Number"
                value={equipment.serialNumber}
                onChange={(e) => handleEquipmentChange(index, 'serialNumber', e.target.value)}
              />
              <input
                placeholder="Health Condition"
                value={equipment.healthCondition}
                onChange={(e) => handleEquipmentChange(index, 'healthCondition', e.target.value)}
              />
              <input
                placeholder="Remarks"
                value={equipment.remarks}
                onChange={(e) => handleEquipmentChange(index, 'remarks', e.target.value)}
              />
            </div>
          </div>
        ))}
        <button onClick={addEquipment}>Add</button>
      </div>
      <div className="signature-section">
        <div className="signature-signature">
          <div className="signature-label">
            <label>Prepared :</label>
          </div>
          <div className="signature-input">
            <input type="text" placeholder="Prepared By" />
          </div>
          <div className="signature-label">
            <label>Checked :</label>
          </div>
          <div className="signature-input">
            <input type="text" placeholder="Checked By" />
          </div>
          <div className="signature-label">
            <label>Approved :</label>
          </div>
          <div className="signature-input">
            <input type="text" placeholder="Approved By" />
          </div>
        </div>
        <div className="signature-signature">
          <div className="signature-label">
            <label>Signature:</label>
          </div>
          <div className="signature-input">
            <input type="text" placeholder="Prepared By" />
          </div>
          <div className="signature-label">
            <label>Signature:</label>
          </div>
          <div className="signature-input">
            <input type="text" placeholder="Checked By" />
          </div>
          <div className="signature-label">
            <label>Signature:</label>
          </div>
          <div className="signature-input">
            <input type="text" placeholder="Approved By" />
          </div>
        </div>
      </div>
      <div className="flight-section">
        {/* <h3>Personnel Details</h3> */}
        {flightData.map((flight, index) => (
          <div key={index} className="flight-container">
            {index === 0 && (
              <div className="flight-labels">
                <label>Flight No:</label>
                <label>Equipment:</label>
                <label>Flight Start Time:</label>
                <label>Flight End Time:</label>
                <label>Remark:</label>
              </div>
            )}
            <div className="flight-inputs">
              <input
                placeholder="Flight No"
                value={flight.FlightNo}
                onChange={(e) => handleFlightChange(index, 'FlightNo', e.target.value)}
              />
              <input
                placeholder="Equipment"
                value={flight.Equipment}
                onChange={(e) => handleFlightChange(index, 'Equipment', e.target.value)}
              />
              <input
              type='time'
                placeholder="Flight Start Time"
                value={flight.FlightStartTime}
                onChange={(e) => handleFlightChange(index, 'FlightStartTime', e.target.value)}
              />
              <input
              type='time'
                placeholder="Flight End Time"
                value={flight.FlightEndTime}
                onChange={(e) => handleFlightChange(index, 'FlightEndTime', e.target.value)}
              />
              <input
                placeholder="Remark"
                value={flight.Remark}
                onChange={(e) => handleFlightChange(index, 'Remark', e.target.value)}
              />
            </div>
          </div>
        ))}
        <button onClick={addFlight}>Add</button>
      </div>
      {/* Additional Section */}
      <div className="additional-section">
        <div className="additional-labels">
          <label>Total Work:</label>
          <label>Total Done:</label>
          <label>Today's Work:</label>
          <label>Total Remaining:</label>
        </div>
        <div className="additional-input">
          <input type="text" placeholder="Total Work" />
          <input type="text" placeholder="Total Done" />
          <input type="text" placeholder="Today's Work" />
          <input type="text" placeholder="Total Remaining" />
        </div>
      </div>
    </div>
  );
};

export default DPRreport;