// import React, { useState } from 'react';
// import { Link } from 'react-router-dom';
// import './CheckList.css';

// const CheckList = () => {
//     const [beforeTakeOffChecked, setBeforeTakeOffChecked] = useState(false);
//     const [afterTakeOffChecked, setAfterTakeOffChecked] = useState(false);
//     const [afterLandingChecked, setAfterLandingChecked] = useState(false);

//     const handleBeforeTakeOffChange = () => {
//         setBeforeTakeOffChecked(!beforeTakeOffChecked);
//         setAfterTakeOffChecked(false);
//         setAfterLandingChecked(false);
//     };

//     const handleAfterTakeOffChange = () => {
//         setAfterTakeOffChecked(!afterTakeOffChecked);
//         setBeforeTakeOffChecked(false);
//         setAfterLandingChecked(false);
//     };

//     const handleAfterLandingChange = () => {
//         setAfterLandingChecked(!afterLandingChecked);
//         setBeforeTakeOffChecked(false);
//         setAfterTakeOffChecked(false);
//     };

//     return (
//         <div className="checklist-container">
//             <h2>Checklist</h2>

//             <div className="checklist-item">
//                 <label>
//                     <input
//                         type="checkbox"
//                         checked={beforeTakeOffChecked}
//                         onChange={handleBeforeTakeOffChange}
//                     />
//                     Before take-off
//                 </label>
//             </div>

//             {beforeTakeOffChecked && (
//                 <ul>

//                     <li>PPE Kits: Gloves/ Vest/ Shoes/ Goggles</li>
//                     <li>Aircraft Airworthiness: Motors/ Propellers/ landing Gear/ Arms/ calibration/ Nozzle/ Rc communication</li>
//                     <li>Battery Voltage:</li>
//                     <li>Kml file and mission Planning, (confirm the area with the farmer)</li>
//                     <li>Obstacles and collision avoidance sensors</li>
//                     <li>Any terrain or obstacles in the area</li>
//                 </ul>
//             )}

//             <div className="checklist-item">
//                 <label>
//                     <input
//                         type="checkbox"
//                         checked={afterTakeOffChecked}
//                         onChange={handleAfterTakeOffChange}
//                     />
//                     After take-off
//                 </label>
//             </div>

//             {afterTakeOffChecked && (
//                 <ul>
//                     <li>Battery monitoring</li>
//                     <li>Co-pilot to monitor the drone</li>
//                     <li>Pilot to monitor drone in the GCS while flying</li>
//                     <li>Any obstacle or hinderances</li>
//                     <li>Photos during spray: 2 in each flight</li>
//                 </ul>
//             )}

//             <div className="checklist-item">
//                 <label>
//                     <input
//                         type="checkbox"
//                         checked={afterLandingChecked}
//                         onChange={handleAfterLandingChange}
//                     />
//                     After Landing
//                 </label>
//             </div>
//             {afterLandingChecked && (
//                 <ul>
//                     <li>Check the battery voltage</li>
//                     <li>Check the arms</li>
//                     <li>Check the nozzle</li>
//                     <li>Charge the batteries</li>
//                     <li>Refill the tank if needed</li>
//                 </ul>
//             )}
//             <Link to="/DPR Report">
//                 <button className="NextButton"> Next </button>
//             </Link>
//         </div>
//     );
// };

// export default CheckList;

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './CheckList.css';

const CheckList = () => {
    const [checklistItems, setChecklistItems] = useState({
        beforeTakeOffChecked: false,
        afterTakeOffChecked: false,
        afterLandingChecked: false,
    });

    const handleCheckboxChange = (itemName) => {
        setChecklistItems((prevState) => ({
            ...prevState,
            [itemName]: !prevState[itemName],
        }));
    };

    return (
        <div className="checklist-container">
            <h2>Checklist</h2>

            <div className="checklist-item">
                <label>
                    <input
                        type="checkbox"
                        checked={checklistItems.beforeTakeOffChecked}
                        onChange={() => handleCheckboxChange('beforeTakeOffChecked')}
                    />
                    Before take-off
                </label>
            </div>

            {checklistItems.beforeTakeOffChecked && (
                <ul>
                    <li>PPE Kits: Gloves/ Vest/ Shoes/ Goggles</li>
                    <li>Aircraft Airworthiness: Motors/ Propellers/ landing Gear/ Arms/ calibration/ Nozzle/ Rc communication</li>
                    <li>Battery Voltage:</li>
                    <li>Kml file and mission Planning, (confirm the area with the farmer)</li>
                    <li>Obstacles and collision avoidance sensors</li>
                    <li>Any terrain or obstacles in the area</li>
                </ul>
            )}

            <div className="checklist-item">
                <label>
                    <input
                        type="checkbox"
                        checked={checklistItems.afterTakeOffChecked}
                        onChange={() => handleCheckboxChange('afterTakeOffChecked')}
                    />
                    After take-off
                </label>
            </div>

            {checklistItems.afterTakeOffChecked && (
                <ul>
                    <li>Battery monitoring</li>
                    <li>Co-pilot to monitor the drone</li>
                    <li>Pilot to monitor drone in the GCS while flying</li>
                    <li>Any obstacle or hinderances</li>
                    <li>Photos during spray: 2 in each flight</li>
                </ul>
            )}

            <div className="checklist-item">
                <label>
                    <input
                        type="checkbox"
                        checked={checklistItems.afterLandingChecked}
                        onChange={() => handleCheckboxChange('afterLandingChecked')}
                    />
                    After Landing
                </label>
            </div>

            {checklistItems.afterLandingChecked && (
                <ul>
                    <li>Check the battery voltage</li>
                    <li>Check the arms</li>
                    <li>Check the nozzle</li>
                    <li>Charge the batteries</li>
                    <li>Refill the tank if needed</li>
                </ul>
            )}

            <Link to="/DPR Report">
                <button className="NextButton"> Next </button>
            </Link>
        </div>
    );
};

export default CheckList;
